"""
Atomcamp Smart LMS - Backend API
Flask + Python
Run: python app.py
"""

from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import os
import json
import uuid
from datetime import datetime

app = Flask(__name__, static_folder='../frontend', static_url_path='')
CORS(app)

UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# ============================================================
# SERVE FRONTEND (for local all-in-one running)
# ============================================================
@app.route('/')
def index():
    return send_from_directory(app.static_folder, 'index.html')

@app.route('/<path:path>')
def static_files(path):
    return send_from_directory(app.static_folder, path)

# ============================================================
# HEALTH CHECK
# ============================================================
@app.route('/api/health', methods=['GET'])
def health():
    return jsonify({"status": "ok", "message": "Atomcamp LMS API running", "time": datetime.now().isoformat()})

# ============================================================
# LEARNER ROUTES
# ============================================================

# Dummy in-memory DB
learners_db = [
    {"id": "L001", "name": "Ayesha Khan", "course": "Python Bootcamp", "progress": 22, "status": "struggling"},
    {"id": "L002", "name": "Bilal Raza", "course": "Web Dev", "progress": 35, "status": "struggling"},
    {"id": "L003", "name": "Zara Ahmed", "course": "Python", "progress": 98, "status": "excelling"},
    {"id": "L004", "name": "Omar Sheikh", "course": "Web Dev", "progress": 96, "status": "excelling"},
    {"id": "L005", "name": "Sara Malik", "course": "Data Science", "progress": 18, "status": "struggling"},
    {"id": "L006", "name": "Hamza Tariq", "course": "AI Basics", "progress": 41, "status": "average"},
    {"id": "L007", "name": "Nida Fatima", "course": "AI/ML", "progress": 94, "status": "excelling"},
    {"id": "L008", "name": "Ali Hassan", "course": "Data Science", "progress": 91, "status": "excelling"},
]

@app.route('/api/learners', methods=['GET'])
def get_learners():
    status = request.args.get('status')
    if status:
        filtered = [l for l in learners_db if l['status'] == status]
        return jsonify({"learners": filtered, "count": len(filtered)})
    return jsonify({"learners": learners_db, "count": len(learners_db)})

@app.route('/api/learners/<learner_id>', methods=['GET'])
def get_learner(learner_id):
    learner = next((l for l in learners_db if l['id'] == learner_id), None)
    if not learner:
        return jsonify({"error": "Learner not found"}), 404
    return jsonify(learner)

@app.route('/api/learners/<learner_id>/nudge', methods=['POST'])
def nudge_learner(learner_id):
    learner = next((l for l in learners_db if l['id'] == learner_id), None)
    if not learner:
        return jsonify({"error": "Learner not found"}), 404
    # In production: send email/SMS here
    return jsonify({
        "success": True,
        "message": f"Nudge sent to {learner['name']} for course '{learner['course']}'",
        "timestamp": datetime.now().isoformat()
    })

# ============================================================
# ANALYTICS / STATS
# ============================================================
@app.route('/api/stats', methods=['GET'])
def get_stats():
    return jsonify({
        "total_learners": 2418,
        "active_this_week": 1847,
        "completion_rate": 94.2,
        "certificates_issued": 312,
        "courses": {
            "Python": 32,
            "Web Dev": 28,
            "Data Science": 18,
            "AI/ML": 14,
            "Cybersecurity": 8
        },
        "monthly_enrollments": {
            "Jan": 120, "Feb": 185, "Mar": 210, "Apr": 175,
            "May": 260, "Jun": 310, "Jul": 290, "Aug": 340,
            "Sep": 400, "Oct": 380, "Nov": 420, "Dec": 460
        }
    })

# ============================================================
# EXCEL FILE UPLOAD
# ============================================================
@app.route('/api/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({"error": "No file in request"}), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "No file selected"}), 400

    allowed = {'xlsx', 'xls', 'csv'}
    ext = file.filename.rsplit('.', 1)[-1].lower()
    if ext not in allowed:
        return jsonify({"error": f"File type .{ext} not allowed. Use .xlsx, .xls or .csv"}), 400

    filename = f"{uuid.uuid4().hex}_{file.filename}"
    filepath = os.path.join(UPLOAD_FOLDER, filename)
    file.save(filepath)

    # Parse file
    try:
        import pandas as pd
        if ext == 'csv':
            df = pd.read_csv(filepath)
        else:
            df = pd.read_excel(filepath)

        preview = df.head(10).to_dict(orient='records')
        columns = list(df.columns)
        numeric_cols = list(df.select_dtypes(include='number').columns)

        # Auto chart data
        chart_data = {}
        for col in numeric_cols[:3]:
            chart_data[col] = df[col].dropna().tolist()[:50]

        return jsonify({
            "success": True,
            "filename": filename,
            "rows": len(df),
            "columns": columns,
            "numeric_columns": numeric_cols,
            "preview": preview,
            "chart_data": chart_data
        })

    except ImportError:
        return jsonify({
            "success": True,
            "filename": filename,
            "message": "File saved. Install pandas for full parsing: pip install pandas openpyxl"
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ============================================================
# AI LEARNING PATH (Placeholder for AI integration)
# ============================================================
@app.route('/api/learner/<learner_id>/ai-path', methods=['GET'])
def ai_path(learner_id):
    learner = next((l for l in learners_db if l['id'] == learner_id), None)
    if not learner:
        return jsonify({"error": "Learner not found"}), 404

    progress = learner['progress']

    if progress < 30:
        recommendation = {
            "level": "Beginner",
            "next_module": "Fundamentals Review",
            "suggested_resources": ["Intro Video", "Practice Quiz", "1-on-1 Session"],
            "estimated_time": "2 hours",
            "alert": "Needs immediate attention"
        }
    elif progress < 70:
        recommendation = {
            "level": "Intermediate",
            "next_module": "Core Concepts Deep Dive",
            "suggested_resources": ["Module 3", "Project Assignment", "Peer Review"],
            "estimated_time": "3 hours",
            "alert": None
        }
    else:
        recommendation = {
            "level": "Advanced",
            "next_module": "Capstone Project",
            "suggested_resources": ["Advanced Topics", "Hackathon", "Certification Prep"],
            "estimated_time": "5 hours",
            "alert": None
        }

    return jsonify({
        "learner": learner,
        "ai_recommendation": recommendation,
        "generated_at": datetime.now().isoformat()
    })

# ============================================================
# COURSES
# ============================================================
courses_db = [
    {"id": "C001", "name": "Python Bootcamp", "enrolled": 780, "completion": 91, "instructor": "Dr. Ahmed"},
    {"id": "C002", "name": "Web Development", "enrolled": 620, "completion": 88, "instructor": "Usman Ali"},
    {"id": "C003", "name": "Data Science", "enrolled": 430, "completion": 79, "instructor": "Sara Khan"},
    {"id": "C004", "name": "AI/ML Fundamentals", "enrolled": 340, "completion": 85, "instructor": "Dr. Raza"},
    {"id": "C005", "name": "Cybersecurity", "enrolled": 248, "completion": 92, "instructor": "Hamid Mir"},
]

@app.route('/api/courses', methods=['GET'])
def get_courses():
    return jsonify({"courses": courses_db, "count": len(courses_db)})

# ============================================================
if __name__ == '__main__':
    print("=" * 50)
    print("  Atomcamp Smart LMS - Backend Running")
    print("  URL: http://localhost:5000")
    print("  API: http://localhost:5000/api/health")
    print("=" * 50)
    app.run(debug=True, port=5000)
