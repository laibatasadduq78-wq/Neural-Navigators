# ⚛️ Atomcamp Smart LMS
### AUREX'26 AI Hackathon — Smart Adaptive Learning System

---

## 📁 Project Structure

```
atomcamp-lms/
├── frontend/
│   ├── index.html        ← Main landing page
│   ├── dashboard.html    ← Instructor dashboard
│   ├── style.css         ← All styles
│   └── app.js            ← Excel upload + charts logic
│
├── backend/
│   ├── app.py            ← Flask API server
│   └── requirements.txt  ← Python dependencies
│
└── README.md
```

---

## 🚀 HOW TO RUN LOCALLY (VS Code)

### Step 1 — Backend Setup
```bash
cd backend
pip install -r requirements.txt
python app.py
```
Backend runs at: **http://localhost:5000**

### Step 2 — Frontend
Just open `frontend/index.html` in your browser.
Or use VS Code Live Server extension (right-click → Open with Live Server).

---

## 🌐 HOW TO DEPLOY

### Frontend → Deploy on Netlify (FREE)
1. Go to https://netlify.com → Sign up
2. Drag & drop your `frontend/` folder onto Netlify dashboard
3. Done! You get a live URL like `https://atomcamp-lms.netlify.app`

### Backend → Deploy on Render (FREE)
1. Push your project to GitHub
2. Go to https://render.com → New Web Service
3. Connect your GitHub repo
4. Set:
   - **Root Directory**: `backend`
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `gunicorn app:app`
5. Deploy → You get a URL like `https://atomcamp-api.onrender.com`

### After Deployment
In `frontend/app.js`, update the API base URL:
```js
const API_BASE = 'https://atomcamp-api.onrender.com'; // your render URL
```

---

## 📡 API ENDPOINTS

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/health` | Check server status |
| GET | `/api/stats` | Dashboard stats |
| GET | `/api/learners` | All learners |
| GET | `/api/learners?status=struggling` | Filter by status |
| GET | `/api/learners/:id` | Single learner |
| POST | `/api/learners/:id/nudge` | Send nudge to learner |
| GET | `/api/learners/:id/ai-path` | AI learning recommendation |
| GET | `/api/courses` | All courses |
| POST | `/api/upload` | Upload Excel/CSV file |

---

## ✨ Features

- 🎨 Professional dark UI with purple/teal color scheme
- 📊 Excel/CSV upload with automatic chart generation
- 🤖 AI-based learning path recommendations
- 👥 Learner tracking (struggling / excelling)
- 📈 Real-time analytics dashboard
- 🔔 One-click nudge system for instructors
- 📱 Responsive design (mobile ready)

---

Built with ❤️ for **AUREX'26 AI Hackathon** · Atomcamp Pakistan
