// ===== ATOMCAMP LMS - APP.JS =====
// Excel Upload + Chart Generation Logic

let workbookData = [];
let headers = [];
let currentChart = null;
const COLORS = ['#8b5cf6','#06b6d4','#f97316','#ec4899','#22c55e','#3b82f6','#f59e0b','#ef4444'];

// ---- DRAG & DROP ----
const uploadArea = document.getElementById('uploadArea');
const fileInput = document.getElementById('fileInput');

if (uploadArea) {
  uploadArea.addEventListener('dragover', e => { e.preventDefault(); uploadArea.classList.add('drag-over'); });
  uploadArea.addEventListener('dragleave', () => uploadArea.classList.remove('drag-over'));
  uploadArea.addEventListener('drop', e => {
    e.preventDefault(); uploadArea.classList.remove('drag-over');
    const file = e.dataTransfer.files[0];
    if (file) processFile(file);
  });
  uploadArea.addEventListener('click', () => fileInput.click());
}

if (fileInput) {
  fileInput.addEventListener('change', e => {
    if (e.target.files[0]) processFile(e.target.files[0]);
  });
}

// ---- PROCESS FILE ----
function processFile(file) {
  const ext = file.name.split('.').pop().toLowerCase();
  if (!['xlsx','xls','csv'].includes(ext)) {
    alert('Please upload .xlsx, .xls, or .csv file only!');
    return;
  }

  const reader = new FileReader();
  reader.onload = e => {
    const data = e.target.result;
    let wb;
    if (ext === 'csv') {
      wb = XLSX.read(data, { type: 'string' });
    } else {
      wb = XLSX.read(data, { type: 'array' });
    }
    const sheet = wb.Sheets[wb.SheetNames[0]];
    const json = XLSX.utils.sheet_to_json(sheet, { defval: '' });
    if (!json.length) { alert('File is empty or unreadable!'); return; }

    workbookData = json;
    headers = Object.keys(json[0]);

    showFileInfo(file.name, json.length);
    populateSelects();
    showDataPreview(json);
    showAutoCharts(json);

    document.getElementById('chartControls').classList.remove('hidden');
    document.getElementById('dataPreview').classList.remove('hidden');
    document.getElementById('autoCharts').classList.remove('hidden');
  };

  if (ext === 'csv') reader.readAsText(file);
  else reader.readAsArrayBuffer(file);
}

function showFileInfo(name, rows) {
  const el = document.getElementById('fileInfo');
  el.textContent = `✅ File loaded: "${name}" — ${rows} rows, ${headers.length} columns detected`;
  el.classList.remove('hidden');
}

function populateSelects() {
  ['xAxis','yAxis'].forEach(id => {
    const sel = document.getElementById(id);
    sel.innerHTML = headers.map(h => `<option value="${h}">${h}</option>`).join('');
  });
  // Default y to second column if exists
  if (headers.length > 1) document.getElementById('yAxis').value = headers[1];
}

function showDataPreview(json) {
  const container = document.getElementById('tableContainer');
  const preview = json.slice(0, 8);
  let html = '<table><thead><tr>' + headers.map(h => `<th>${h}</th>`).join('') + '</tr></thead><tbody>';
  preview.forEach(row => {
    html += '<tr>' + headers.map(h => `<td>${row[h]}</td>`).join('') + '</tr>';
  });
  html += '</tbody></table>';
  container.innerHTML = html;
}

// ---- GENERATE CHART ----
function generateChart() {
  const xCol = document.getElementById('xAxis').value;
  const yCol = document.getElementById('yAxis').value;
  const type = document.getElementById('chartType').value;

  const labels = workbookData.map(r => String(r[xCol]));
  const values = workbookData.map(r => parseFloat(r[yCol]) || 0);

  document.getElementById('chartTitle').textContent = `${yCol} by ${xCol}`;
  document.getElementById('chartContainer').classList.remove('hidden');
  renderChart('myChart', type, labels, values, `${yCol} by ${xCol}`);
}

function renderChart(canvasId, type, labels, values, title) {
  const ctx = document.getElementById(canvasId).getContext('2d');
  if (canvasId === 'myChart' && currentChart) { currentChart.destroy(); }

  const isPie = ['pie','doughnut'].includes(type);
  const chart = new Chart(ctx, {
    type,
    data: {
      labels,
      datasets: [{
        label: title,
        data: values,
        backgroundColor: isPie ? COLORS : COLORS[0] + '99',
        borderColor: isPie ? COLORS : COLORS[0],
        borderWidth: isPie ? 0 : 2,
        tension: 0.4, fill: type === 'line',
        pointRadius: type === 'line' ? 4 : 0,
        pointBackgroundColor: COLORS[0],
        hoverOffset: isPie ? 8 : 0
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: { display: isPie, labels: { color: '#94a3b8', padding: 16 } },
        tooltip: {
          backgroundColor: '#16162a', titleColor: '#f1f5f9',
          bodyColor: '#94a3b8', borderColor: 'rgba(255,255,255,0.07)', borderWidth: 1
        }
      },
      scales: isPie ? {} : {
        x: { ticks: { color: '#94a3b8', maxTicksLimit: 12 }, grid: { color: 'rgba(255,255,255,0.04)' } },
        y: { ticks: { color: '#94a3b8' }, grid: { color: 'rgba(255,255,255,0.06)' } }
      }
    }
  });

  if (canvasId === 'myChart') currentChart = chart;
  return chart;
}

// ---- AUTO CHARTS ----
function showAutoCharts(json) {
  const grid = document.getElementById('autoChartsGrid');
  grid.innerHTML = '';

  const numericCols = headers.filter(h => json.some(r => !isNaN(parseFloat(r[h])) && r[h] !== ''));
  const textCols = headers.filter(h => !numericCols.includes(h));
  const labelCol = textCols[0] || headers[0];

  const configs = [];
  numericCols.slice(0, 3).forEach((col, i) => {
    configs.push({ title: `${col} Distribution`, type: i === 0 ? 'bar' : i === 1 ? 'line' : 'doughnut', yCol: col });
  });
  if (configs.length === 0 && headers.length >= 2) {
    configs.push({ title: `${headers[1]} by ${headers[0]}`, type: 'bar', yCol: headers[1] });
  }

  configs.forEach((cfg, idx) => {
    const card = document.createElement('div');
    card.className = 'auto-chart-card';
    const id = `auto-chart-${idx}`;
    card.innerHTML = `<h4>${cfg.title}</h4><canvas id="${id}" height="200"></canvas>`;
    grid.appendChild(card);

    const labels = json.map(r => String(r[labelCol]));
    const values = json.map(r => parseFloat(r[cfg.yCol]) || 0);
    setTimeout(() => renderChart(id, cfg.type, labels, values, cfg.title), 100 * idx);
  });
}

// ---- DOWNLOAD CHART ----
function downloadChart() {
  const canvas = document.getElementById('myChart');
  const link = document.createElement('a');
  link.download = 'atomcamp-chart.png';
  link.href = canvas.toDataURL('image/png');
  link.click();
}
